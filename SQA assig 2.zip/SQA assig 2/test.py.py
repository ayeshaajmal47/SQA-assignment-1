#Ayesha Ajmal
#Roll no: 221436198
#Assignment no 2


import time
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time


driver= webdriver.Chrome("C:\\Users\\ayesh\\AppData\\Local\\Programs\\Python\\Python310\\Scripts\\chromedriver.exe")

#Selenium commands to be tested on web application using python language

#get function
driver.get("https://www.facebook.com")

#maximize window
driver.maximize_window()

#Refresh window
driver.refresh()

#Entering username
driver.find_element("id","email").send_keys('ayeshaajmal55@gmail.com')

time.sleep(3)

#entering password
driver.find_element("id","pass").send_keys('ayeshaajmal55')

time.sleep(3)

#navigate back
driver.back()

print(driver.title)



#Get and post requests record
driver.get("http://www.facebook.com")
assert driver.requests[0].response.status_code == 200 or driver.requests[0].response.status_code == 302, "status code is not 200 or 302"
print('\n')
print("API testing using Selenium")
print("Format: method, host, status code, date and time")
for each in driver.requests[:10]:
    if each.response:
        print(each.method, each.host, each.response.status_code, each.response.date, end='\n')
        print("______________________")





